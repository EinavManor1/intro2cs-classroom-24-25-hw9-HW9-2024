/**
 * Represents a managed memory space.
 * Manages allocated and free memory blocks with methods to allocate (`malloc`),
 * free, and defragment the space.
 */
public class MemorySpace {

    // Lists for allocated and free memory blocks
    private LinkedList allocatedList;
    private LinkedList freeList;

    /**
     * Constructs a new managed memory space of a given maximal size.
     * 
     * @param maxSize the size of the memory space to be managed.
     */
    public MemorySpace(int maxSize) {
        allocatedList = new LinkedList();
        freeList = new LinkedList();
        freeList.addLast(new MemoryBlock(0, maxSize));
    }

    /**
     * Allocates a memory block of a requested length.
     * 
     * @param length the length of the memory block to allocate.
     * @return the base address of the allocated block, or -1 if unable to allocate.
     */
    public int malloc(int length) {
		if (length <= 0) {
			System.out.println("Invalid allocation request: " + length);
			return -1;
		}
	
		Node current = freeList.getFirst();
		System.out.println("Starting malloc for length: " + length);
		while (current != null) {
			MemoryBlock block = current.block;
			System.out.println("Inspecting free block: " + block);
	
			if (block.getLength() >= length) {
				MemoryBlock allocated = new MemoryBlock(block.getBaseAddress(), length);
				allocatedList.addLast(allocated);
				System.out.println("Allocated block: " + allocated);
	
				if (block.getLength() == length) {
					freeList.remove(current); // Exact match
					System.out.println("Exact match. Block removed from free list.");
				} else {
					block.setBaseAddress(block.getBaseAddress() + length); // Update base address
					block.setLength(block.getLength() - length);           // Update length
					System.out.println("Split block. Remaining free block: " + block);
				}
	
				System.out.println("Current free list: " + freeList);
				System.out.println("Current allocated list: " + allocatedList);
				return allocated.getBaseAddress();
			}
	
			current = current.next;
		}
	
		System.out.println("Allocation failed. No suitable block found.");
		return -1;
	}

    /**
     * Frees the memory block whose base address matches the given address.
     * 
     * @param address the base address of the block to free.
     */
    public void free(int address) {
        System.out.println("Freeing memory at address: " + address);
		if (allocatedList.getSize() == 0) {
            System.out.println("No allocated blocks to free.");
			throw new IllegalArgumentException("No allocated blocks to free.");
		}

        Node current = allocatedList.getFirst();
        while (current != null) {
            MemoryBlock block = current.block; // Access block directly
            if (block.getBaseAddress() == address) {
                System.out.println("Found block to free: " + block);
				allocatedList.remove(current);
                freeList.addLast(block);
                System.out.println("Block added to freeList. Current state: " + freeList);
				return;
            }
            current = current.next; // Move to the next node
        }
        System.out.println("No block found at address: " + address);
		throw new IllegalArgumentException("No allocated block found with base address: " + address);
    }

    /**
     * Performs defragmentation of the free list by merging adjacent blocks.
     */
    public void defrag() {
        System.out.println("Performing defragmentation...");
    	System.out.println("Initial free list: " + freeList);
		
		if (freeList.getSize() <= 1) {
			System.out.println("No defragmentation needed.");
			return;
		}
        
		Node current = freeList.getFirst();
        while (current != null && current.next != null) {
            MemoryBlock currentBlock = current.block; // Access block directly
            MemoryBlock nextBlock = current.next.block; // Access block directly

            if (currentBlock.canMerge(nextBlock)) {
                System.out.println("Merging blocks: " + currentBlock + " and " + nextBlock);
				currentBlock.merge(nextBlock);
                freeList.remove(current.next); // Remove the merged block
            } else {
                current = current.next; // Move to the next block
            }
		}
	}

    /**
     * A textual representation of the memory space.
     * 
     * @return the string representation of the memory space.
     */
    @Override
	public String toString() {
		StringBuilder freeListString = new StringBuilder();
		StringBuilder allocatedListString = new StringBuilder();
	
		// Format free list
		ListIterator freeIterator = freeList.iterator();
		while (freeIterator.hasNext()) {
			freeListString.append(freeIterator.next().block.toString()).append(" ");
		}
	
		// Format allocated list
		ListIterator allocatedIterator = allocatedList.iterator();
		while (allocatedIterator.hasNext()) {
			allocatedListString.append(allocatedIterator.next().block.toString()).append(" ");
		}
	
		return freeListString.toString().trim() + " \n" + allocatedListString.toString().trim();
	}
}